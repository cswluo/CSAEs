/** @file vl_nnnormalize.cpp
 ** @brief A non-CUDA wrapper
 **/

#include "vl_nnnormalize.cu"